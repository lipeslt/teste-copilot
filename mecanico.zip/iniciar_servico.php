<?php
require 'db_connection.php';

header('Content-Type: application/json');
session_start();

// Verificação robusta de autenticação
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'message' => 'Não autenticado']));
}

// Verificação do método HTTP
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['success' => false, 'message' => 'Método não permitido']));
}

// Leitura e validação do JSON
$input = json_decode(file_get_contents('php://input'), true);
if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    die(json_encode([
        'success' => false,
        'message' => 'JSON inválido',
        'error' => json_last_error_msg()
    ]));
}

// Validação dos campos obrigatórios
if (empty($input['tipo']) || empty($input['id'])) {
    http_response_code(400);
    die(json_encode([
        'success' => false,
        'message' => 'Campos obrigatórios faltando',
        'required_fields' => ['tipo', 'id']
    ]));
}

try {
    $conn->beginTransaction();

    // Verificação da notificação
    $stmt = $conn->prepare("SELECT id FROM notificacoes WHERE id = ? AND status = 'aceito'");
    $stmt->execute([$input['id']]);
    
    if ($stmt->rowCount() === 0) {
        http_response_code(404);
        die(json_encode([
            'success' => false,
            'message' => 'Notificação não encontrada ou já em andamento'
        ]));
    }

    // Criação do serviço
    $stmt = $conn->prepare("
        INSERT INTO servicos_mecanica 
        (mecanico_id, notificacao_id, status, inicio_servico, created_at)
        VALUES (?, ?, 'em_andamento', NOW(), NOW())
    ");
    $stmt->execute([$_SESSION['user_id'], $input['id']]);

    // Atualização da notificação
    $stmt = $conn->prepare("UPDATE notificacoes SET status = 'in_andamento' WHERE id = ?");
    $stmt->execute([$input['id']]);

    $conn->commit();

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'servico_id' => $conn->lastInsertId(),
        'message' => 'Serviço iniciado com sucesso'
    ]);

} catch (PDOException $e) {
    $conn->rollBack();
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro no banco de dados',
        'error_details' => $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}