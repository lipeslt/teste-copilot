<?php
require 'db_connection.php';
session_start();

header('Content-Type: application/json');

try {
    if (empty($_SESSION['user_id'])) {
        throw new Exception('Usuário não autenticado');
    }

    $input = file_get_contents('php://input');
    $data = json_decode($input, true);

    if (!isset($data['tipo']) || !isset($data['id'])) {
        throw new Exception('Parâmetros inválidos');
    }

    $conn->beginTransaction();

    $mecanico_id = $_SESSION['user_id'];
    $tipo = $data['tipo'];
    $id = intval($data['id']);

    if ($tipo === 'notificacao') {
        // Verificar se a notificação existe
        $stmt = $conn->prepare("SELECT * FROM notificacoes WHERE id = ?");
        $stmt->execute([$id]);
        $notificacao = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$notificacao) {
            throw new Exception('Notificação não encontrada');
        }

        // Verificar se já não está em serviço
        $stmt = $conn->prepare("
            SELECT id FROM servicos_mecanica 
            WHERE notificacao_id = ? AND status IN ('aceito', 'em_andamento')
        ");
        $stmt->execute([$id]);
        if ($stmt->fetch()) {
            throw new Exception('Esta notificação já está em serviço');
        }

        // Inserir o serviço
        $sql = "
            INSERT INTO servicos_mecanica (
                notificacao_id,
                ficha_id,
                mecanico_id,
                secretaria,
                nome_veiculo,
                prefixo,
                observacoes,
                inicio_servico,
                status,
                prioridade,
                created_at,
                updated_at
            ) VALUES (
                ?,         -- notificacao_id
                NULL,      -- ficha_id
                ?,         -- mecanico_id
                ?,         -- secretaria
                ?,         -- nome_veiculo
                ?,         -- prefixo
                ?,         -- observacoes
                NOW(),     -- inicio_servico
                'aceito',  -- status
                'media',   -- prioridade
                NOW(),     -- created_at
                NOW()      -- updated_at
            )
        ";

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $id,                        // notificacao_id
            $mecanico_id,              // mecanico_id
            $notificacao['secretaria'], // secretaria
            $notificacao['nome_veiculo'] ?? '', // nome_veiculo
            $notificacao['prefixo'] ?? '',      // prefixo
            $notificacao['mensagem'] ?? ''      // observacoes (usando a mensagem da notificação)
        ]);

        $novo_servico_id = $conn->lastInsertId();

        // Atualizar status da notificação
        $stmt = $conn->prepare("UPDATE notificacoes SET status = 'aceito' WHERE id = ?");
        $stmt->execute([$id]);

        // Buscar o serviço criado
        $stmt = $conn->prepare("
            SELECT sm.*, 
                   'notificacao' as tipo_origem,
                   n.data as notificacao_data,
                   n.mensagem as notificacao_mensagem
            FROM servicos_mecanica sm
            LEFT JOIN notificacoes n ON sm.notificacao_id = n.id
            WHERE sm.id = ?
        ");
        $stmt->execute([$novo_servico_id]);
        $novo_servico = $stmt->fetch(PDO::FETCH_ASSOC);

        $conn->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Serviço aceito com sucesso',
            'pedido' => $novo_servico
        ]);

    } elseif ($tipo === 'ficha') {
        // ... código existente para fichas ...
    } else {
        throw new Exception('Tipo de origem inválido');
    }

} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollBack();
    }

    error_log("Erro ao aceitar serviço: " . $e->getMessage());
    error_log("Stack trace: " . $e->getTraceAsString());

    echo json_encode([
        'success' => false,
        'message' => 'Erro ao aceitar serviço: ' . $e->getMessage()
    ]);
}

// Garantir que nenhuma saída adicional seja enviada
exit();
?>